-- Ryan deMayo --
-- CMPT 308 Database Design Project --

DROP TABLE IF EXISTS People 
	CASCADE;
DROP TABLE IF EXISTS Performer
	CASCADE;
DROP TABLE IF EXISTS Staff
	CASCADE;
DROP TABLE IF EXISTS Instruments
	CASCADE;
DROP TABLE IF EXISTS Works
	CASCADE;
DROP TABLE IF EXISTS Plays
	CASCADE;
DROP TABLE IF EXISTS Jobs
	CASCADE;
DROP TABLE IF EXISTS Plays_in
	CASCADE;
DROP TABLE IF EXISTS Used_in
	CASCADE;
DROP TABLE IF EXISTS Job_site
	CASCADE;
DROP TABLE IF EXISTS Songs
	CASCADE;
DROP TABLE IF EXISTS Venues
	CASCADE;
DROP TABLE IF EXISTS Concert
	CASCADE;
DROP TABLE IF EXISTS Sets
	CASCADE;
DROP TABLE IF EXISTS Used_in_Sets
	CASCADE;

CREATE TABLE People (
Pid		 		SERIAL	      NOT NULL 		PRIMARY KEY, 
First_Name   	TEXT	 	  NOT NULL,
Last_Name    	TEXT	 	  NOT NULL, 
DateofBirth 	DATE		  NOT NULL,
Gender	 		TEXT	   	  NOT NULL );

CREATE TABLE Performer (
Pid 			SERIAL 		 NOT NULL 	REFERENCES People(Pid),
Pay 			decimal(9,2) NOT NULL,
PRIMARY KEY(Pid));

CREATE TABLE Staff( 
Pid 			SERIAL	 	 NOT NULL 	REFERENCES People(Pid),
HourlyWageUSD 	decimal(6,2) NOT NULL);

CREATE TABLE Instruments (
InstID			SERIAL		NOT NULL 		PRIMARY KEY,
Name			TEXT		NOT NULL	);

CREATE TABLE Plays (
Pid				SERIAL		NOT NULL		REFERENCES People(Pid),
InstID			SERIAL		NOT NULL		REFERENCES Instruments(InstID),
PRIMARY KEY (Pid, InstID));

CREATE TABLE Songs (
SongID 			SERIAL		NOT NULL		PRIMARY KEY,
Name			Text		NOT NULL,
Length			Time		NOT NULL);

CREATE TABLE Used_in (
SongID			SERIAL		NOT NULL		REFERENCES Songs(SongID),
InstID			SERIAL		NOT NULL		REFERENCES Instruments(InstID));

CREATE TABLE Plays_in (
Pid				SERIAL		NOT NULL		REFERENCES People(Pid),
SongID			SERIAL		NOT NULL		REFERENCES Songs(SongID),
PRIMARY KEY(Pid, SongID));

CREATE TABLE Sets (
SetID			SERIAL		NOT NULL		PRIMARY KEY,
SetName			TEXT		NOT NULL,
SetLength		TIME		);

CREATE TABLE Used_in_Sets (
SongID			SERIAL		NOT NULL		REFERENCES Songs(SongID),
SetID			SERIAL		NOT NULL		REFERENCES Sets(SetID),
SongNum			INT			NOT NULL,
PRIMARY KEY(SongID, SetID));

CREATE TABLE Venues (
VenueID 		SERIAL		NOT NULL		PRIMARY KEY,
VenueName		TEXT		NOT NULL,
Address			VARCHAR		NOT NULL);

CREATE TABLE Concert (
VenueID 		SERIAL		NOT NULL		REFERENCES Venues(VenueID),
SetID			SERIAL		NOT NULL 		REFERENCES Sets(SetID),
ConcertDate		DATE		NOT NULL,
Name			TEXT		NOT NULL,
StartTime		TIME		NOT NULL,
PRIMARY KEY (VenueID, SetID, ConcertDate));

CREATE TABLE Jobs(
JobID			SERIAL		NOT NULL		PRIMARY KEY,
JobTitle		TEXT		NOT NULL,
Description		TEXT		NOT NULL);

CREATE TABLE Works (
Pid 			SERIAL 		NOT NULL	REFERENCES People(Pid),
JobID			SERIAL 		NOT NULL	REFERENCES Jobs(JobID));



CREATE TABLE Job_Site (
VenueID 		SERIAL		NOT NULL		REFERENCES Venues(VenueID),
JobID			SERIAL		NOT NULL		REFERENCES Jobs(JobID),
StartTime		TIME		NOT NULL,
PRIMARY KEY (VenueID, JobID));

INSERT INTO People(Pid, First_Name, Last_Name, DateofBirth, Gender)
values(DEFAULT, 'Jeff', 'Tweedy', '1967-08-25', 'Male'),
	  (DEFAULT, 'John', 'Stirratt', '1967-11-26', 'Male'),
      (DEFAULT, 'Glenn', 'Kotche', '1970-12-31', 'Male'),
      (DEFAULT, 'Mikael', 'Jorgensen', '1972-06-04', 'Male'),
      (DEFAULT, 'Nels', 'Cline', '1956-01-04', 'Male'),
      (DEFAULT, 'Pat', 'Sansone', '1969-06-21', 'Male'),
      (DEFAULT, 'Amy', 'Madison', '1980-02-26', 'Female'),
      (DEFAULT, 'Nancy', 'Gardner', '1994-07-23', 'Female'),
      (DEFAULT, 'Mac', 'Demarco', '1983-04-19', 'Male'),
      (DEFAULT, 'Andrew', 'Miller', '1996-05-14', ' Male'),
      (DEFAULT, 'Jimmy', 'McCollen', '1975-10-09', 'Male'),
      (DEFAULT, 'Max', 'Johnston', '1971-08-17', 'Male');
      
INSERT INTO Performer(Pid, Pay)
values(DEFAULT, 99000),
	  (DEFAULT, 10000),
      (DEFAULT, 70),
      (DEFAULT, 12300),
      (DEFAULT, 500),
      (DEFAULT, 5490);
      
      
INSERT INTO INSTRUMENTS(InstID, Name)
values(DEFAULT, 'Guitar'),
	  (DEFAULT, 'Bass'),
      (DEFAULT, 'Drums'),
      (DEFAULT, 'Piano'),
      (DEFAULT, 'Violin'),
      (DEFAULT, 'Vocals'),
      (DEFAULT, 'Trumpet');
      
INSERT INTO Plays(Pid, InstID)
values(001, 001),
	  (002, 006),
      (002, 001),
      (004, 002),
      (001, 006),
      (005, 004),
      (003, 003),
      (006, 005),
      (006, 007);
      
INSERT INTO Songs(SongID, Name, Length)
values(DEFAULT, 'Jesus, etc', '00:03:51'),
	  (DEFAULT, 'Kamera', '00:03:30'),
      (DEFAULT, 'Radio Cure', '00:05:09'),
      (DEFAULT, 'Less than you think', '00:15:01'),
      (DEFAULT, 'Hummingbird', '00:03:07'),
      (DEFAULT, 'Handshake Drugs', '00:06:03'),
      (DEFAULT, 'Misunderstood', '00:06:09'),
      (DEFAULT, 'Either Way', '00:03:06'),
      (DEFAULT, 'Walken', '00:03:35');
      
INSERT INTO Plays_In(Pid, SongID)
values(001, 001),
      (001, 002),
      (001, 003),
      (001, 004),
      (001, 005),
      (001, 006),
      (001, 007),
      (001, 008),
      (001, 009),
      (002, 001),
      (002, 002),
      (002, 003),
      (002, 004),
      (002, 005),
      (002, 006),
      (002, 007),
      (002, 008),
      (002, 009),
      (003, 001),
      (003, 002),
      (003, 003),
      (003, 004),
      (003, 005),
      (003, 006),
      (003, 007),
      (003, 008),
      (003, 009),
      (004, 001),
      (004, 002),
      (004, 003),
      (004, 004),
      (004, 005),
      (004, 006),
      (004, 007),
      (004, 008),
      (004, 009),
      (005, 002),
      (005, 005),
      (005, 006),
      (005, 008),
      (006, 001),
      (006, 005),
      (006, 004),
      (006, 003);
      
INSERT INTO Used_In(InstID, SongID)
values(001, 001),
      (001, 002),
      (001, 003),
      (001, 004),
      (001, 005),
      (001, 006),
      (001, 007),
      (001, 008),
      (001, 009),
      (002, 001),
      (002, 002),
      (002, 003),
      (002, 004),
      (002, 005),
      (002, 006),
      (002, 007),
      (002, 008),
      (002, 009),
      (003, 001),
      (003, 002),
      (003, 003),
      (003, 004),
      (003, 005),
      (003, 006),
      (003, 007),
      (003, 008),
      (003, 009),
      (004, 002),
      (004, 005),
      (004, 006),
      (004, 008),
      (006, 001),
      (006, 002),
      (006, 003),
      (006, 004),
      (006, 005),
      (006, 006),
      (006, 007),
      (006, 008),
      (006, 009),
      (005, 001),
      (005, 004),
      (007, 003),
      (007, 005);
      
INSERT INTO Sets(SetID, SetName, SetLength)
values(DEFAULT, 'Jesus', '00:00:00'),
	  (DEFAULT, 'Jam On', '00:00:00'),
      (DEFAULT, 'Wilco Experience', '00:00:00'),
      (DEFAULT, 'Sampler', '00:00:00');
      
INSERT INTO Used_in_Sets(SetID, SongID, SongNum)
values(001, 001, 001),
	  (001, 004, 002),
      (001, 003, 003),
      (001, 005, 004),
      (002, 007, 001),
      (002, 003, 002),
      (002, 009, 003),
      (002, 008, 004),
      (003, 001, 001),
      (003, 002, 002),
      (003, 003, 003),
      (003, 004, 004),
      (003, 005, 005),
      (003, 006, 006),
      (003, 007, 007),
      (003, 008, 008),
      (003, 009, 009),
      (004, 002, 002),
      (004, 003, 003);
      
INSERT INTO Venues(VenueID, VenueName, Address)
values(001, 'Bowery Ballroom', '6 Delancey St, New York, NY 10002'),
	  (002, 'The Space', '295 Treadwell St, Hamden, CT 06514'),
      (003, 'Terminal 5', '610 W 56th St, New York, NY 10019'),
      (004, 'Riverside Theater', '116 W Wisconsin Ave, Milwaukee, WI 53203'),
      (005, 'Thompsons Point', 'Thompsons Point, Portland, ME 04102'),
      (006, 'The Fillmore', '1805 Geary Blvd, San Francisco, CA 94115');
      

      
INSERT INTO Concert(VenueID, SetId, ConcertDate, Name, StartTime)
values(001, 001, '2017-05-20', 'Wilco @ Bowery', '21:00:00'),
	  (003, 003, '2017-05-23', 'Wilco', '22:00:00'),
      (002, 002, '2017-05-25', 'Wilco @ the Outer Space', '21:00:00'),
      (006, 003, '2017-06-01', 'The Wilco Experience', '18:00:00'),
      (004, 004, '2017-06-05', 'Wilco Riverside', '20:00:00'),
      (005, 004, '2017-06-09', 'WIlco @ Thompsons Point', '21:00:00'),
	  (001, 003, '2017-06-11', 'Bowery Presents Wilco', '20:00:00');
      

INSERT INTO Jobs(JobID, JobTitle, Description)
values(001, 'Road Crew', 'Move and setup equipment from one show to another'),
	  (002, 'Sound Crew', 'Adjusts the volume levels for each instrument during the show'),
      (003, 'Manager', 'Book shows and make sure everything runs smoothly'),
      (004, 'Security', 'Protect the crew and performers'),
      (005, 'Publicity', 'Get people in the door, sell merch');
      
INSERT INTO Staff(Pid, HourlyWageUSD)
values(007, 110.00),
      (008, 75.00),
	  (009, 25.00),
      (010, 15.00),
      (011, 45.00);
      
INSERT INTO Works(Pid, JobID)
values(007, 003),
      (007, 005),
      (008, 001),
      (008, 002),
      (008, 004),
      (009, 001),
      (009, 005),
      (010, 001),
      (010, 004),
      (011, 002);
      
INSERT INTO Job_Site(VenueID, JobID, StartTime)
values(001, 001, '09:00:00'),
	  (002, 001, '10:00:00'),
      (003, 001, '12:00:00'),
      (004, 001, '12:00:00'),
      (005, 001, '11:00:00'),
      (006, 001, '11:00:00'),
      (001, 002, '15:00:00'),
      (002, 002, '15:00:00'),
      (003, 002, '12:00:00'),
      (004, 002, '14:00:00'),
      (005, 002, '15:00:00'),
      (006, 002, '14:30:00'),
      (001, 004, '17:00:00'),
      (002, 004, '18:00:00'),
      (003, 004, '18:00:00'),
      (004, 004, '18:00:00'),
      (005, 004, '18:00:00'),
      (006, 004, '19:00:00'),
      (001, 003, '05:00:00'),
      (005, 005, '09:00:00');
      
-- SetInfo view defined      
      
CREATE OR REPLACE VIEW SetInfo AS
SELECT Sets.SetID, Sets.SetName, Songs.Name, Used_in_Sets.SongNum, Songs.Length
FROM  Songs, Used_in_Sets, Sets
WHERE Sets.SetID = Used_in_Sets.SetID
AND Songs.SongID = Used_in_Sets.SongID
ORDER BY Sets.SetID, Used_in_Sets.SongNum;


-- ConcertSchedule view defined
CREATE OR REPLACE VIEW ConcertSchedule AS
SELECT Concert.Name, Venues.VenueName, Venues.Address, Concert.ConcertDate, Sets.SetName
FROM Venues, Concert, Sets
WHERE Venues.VenueID = Concert.VenueID
AND Sets.SetID = Concert.SetID
ORDER BY Concert.ConcertDate;


-- Returns the names of all performers that play Jesus, etc and their instruments
SELECT DISTINCT People.Pid, People.First_Name, People.Last_Name, Instruments.Name, Songs.Name
FROM People, Performer, Plays, Instruments, Plays_in, Used_In, Songs
WHERE People.Pid = Performer.Pid
AND Performer.Pid = Plays_in.Pid
AND Songs.SongID = Plays_in.SongID
AND Songs.Name = 'Jesus, etc'
AND Performer.Pid = Plays.Pid
AND Plays.InstID = Instruments.InstID
AND Instruments.InstID = Used_in.InstID
AND Used_In.SongID = Songs.SongID;

-- Returns all instruments that will be used in the show at Riverside Theater
SELECT DISTINCT Instruments.name
FROM Concert, Venues, Sets, Used_in_Sets, Songs, Used_in, Instruments
WHERE Instruments.InstID = Used_In.InstID
AND Used_In.SongID = Songs.SongID
AND Used_in_Sets.SongID = Songs.SongID
AND Used_in_Sets.SetID = Sets.SetID
AND Concert.SetID = Sets.SetID
AND Venues.VenueID = Concert.VenueID
AND Venues.VenueName = 'Riverside Theater'
AND Instruments.Name != 'Vocals'
ORDER BY Instruments.Name;

create role manager;
grant all on all tables in schema public to manager;

create role crew;
revoke all on all tables in schema public from crew;
grant SELECT on Instruments, Used_In, Songs, 
Used_in_Sets, Sets, Concert, Venues to crew;


-- calculates and displays the least active performers

create or replace function PlaysLeast(REFCURSOR) returns
refcursor AS 
$body$ DECLARE
	num INT := (SELECT MIN(temp.PlayCount)
                FROM (SELECT Performer.Pid, count(Performer.Pid) as PlayCount
                      FROM Songs inner join Plays_in on Songs.SongID = Plays_in.SongID
                      inner join Performer on Plays_in.Pid = Performer.Pid
                      GROUP BY Performer.Pid) temp);
                      result refcursor := $1;
       BEGIN 
       OPEN result FOR
       			SELECT Performer.Pid, People.First_Name, People.Last_Name, COUNT(Performer.Pid)
                as PlayCount
                FROM Performer INNER JOIN Plays_in on Performer.Pid = Plays_in.Pid
                INNER JOIN People on Performer.Pid = People.Pid
                INNER JOIN Songs on Plays_in.SongID = Songs.SongID
                GROUP BY Performer.Pid, People.First_Name, People.Last_Name
                HAVING COUNT(Performer.Pid) = num;
              RETURN result;
     	end;
        $body$ LANGUAGE plpgsql;
        
        
        SELECT PlaysLeast('ref');
        FETCH ALL FROM REF;
        
        
CREATE OR REPLACE FUNCTION SetLengthCalculator() RETURNS 
TRIGGER AS $body$
DECLARE 
	rec record;
    temptime time;
	loopcount integer;        
BEGIN	
	loopcount = 1;
    rec = COUNT(Sets.SetID) FROM Sets;
	while (loopcount < rec)
    LOOP    
    temptime = sum(Songs.Length)
   	 					FROM Songs, Used_in_Sets, Sets
    					WHERE Songs.SongID = Used_in_Sets.SongID       					
    					AND Sets.SetID = Used_in_Sets.SetID
        				AND Sets.SetID = loopcount;
    UPDATE Sets
    SET Sets.SetLength = temptime
     where Sets.SetID = loopcount;                
     loopcount = loopcount + 1;
    
     
	RETURN NEW; END;
$body$ LANGUAGE plpgsql;
        
        
CREATE TRIGGER UpdateSetLength
BEFORE INSERT OR UPDATE ON Sets
FOR EACH ROW
EXECUTE PROCEDURE SetLengthCalculator();

SELECT *
FROM Sets;
                      
                





                




